$(() => {
  let result = 1;
  $('.dash').click(() => {
    result--;
    result = result < 1 ? 1 : result;
    $("#result").text(result);
  });

  $('.plus').click(() => {
    result++;
    $("#result").text(result);
  });
});


$(document).ready(function () {
  $('#buy').click(function () {
    if(confirm("구매 하시겠습니까?")){
      alert("구매가 완료되었습니다.");
    }
  });
  $('#basket').click(function () {   
    alert("장바구니에 담겼습니다.");
});
function updateTotal() {
  var won = parseInt($("#won").text().replace(/,/g, ''));
  var result = parseInt($("#result").text());
  var total = won * result;
  var formattedTotal = total.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  $("#money").text(formattedTotal);
}
updateTotal();
window.plus = function() {
  var currentResult = parseInt($("#result").text());
  $("#result").text(currentResult + 1);
  updateTotal();
};
window.dash = function() {
  var currentResult = parseInt($("#result").text());
  if (currentResult > 1) {
    $("#result").text(currentResult - 1);
    updateTotal();
  }
};
});






